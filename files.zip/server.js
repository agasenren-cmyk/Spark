const express = require('express');
const cors = require('cors');
const fetch = require('node-fetch');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' })); // large limit for base64 images
app.use(express.static('public')); // serves your HTML frontend

// ─── SCORE FACE ENDPOINT ─────────────────────────────
app.post('/api/score-face', async (req, res) => {
  const { image, mediaType } = req.body;

  if (!image) {
    return res.status(400).json({ error: 'No image provided' });
  }

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,  // 🔒 key stays on server
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 100,
        messages: [{
          role: 'user',
          content: [
            {
              type: 'image',
              source: {
                type: 'base64',
                media_type: mediaType || 'image/jpeg',
                data: image
              }
            },
            {
              type: 'text',
              text: `You are an AI for a dating app. Analyze the face in this image and give a facial attractiveness score from 1.0 to 10.0 (one decimal place). Base it on conventional facial symmetry, features, and attractiveness. Be generous but realistic. Respond with ONLY a number like: 7.3`
            }
          ]
        }]
      })
    });

    const data = await response.json();

    if (!response.ok) {
      console.error('Anthropic API error:', data);
      return res.status(500).json({ error: 'API error', details: data });
    }

    const text = data.content?.[0]?.text?.trim() || '';
    const score = parseFloat(text);

    if (isNaN(score) || score < 1 || score > 10) {
      // Fallback if model returns unexpected output
      return res.json({ score: parseFloat((Math.random() * 4 + 5).toFixed(1)) });
    }

    res.json({ score });

  } catch (err) {
    console.error('Server error:', err);
    res.status(500).json({ error: 'Server error', message: err.message });
  }
});

// ─── START ────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`✦ SPARK backend running at http://localhost:${PORT}`);
});
